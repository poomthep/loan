-- สคีมาขั้นต่ำ
create table if not exists public.user_profiles (
  id uuid primary key references auth.users on delete cascade,
  role text default 'user' check (role in ('user','admin'))
);

create table if not exists public.banks (
  id bigserial primary key,
  short_name text,
  name text,
  mrr numeric,
  mrr_effective_from date
);

create table if not exists public.promotions (
  id bigserial primary key,
  bank_id bigint references public.banks(id) on delete cascade,
  product_type text not null,
  title text not null,
  base text,
  y1 numeric,
  y2 numeric,
  y3 numeric,
  active boolean default true
);
